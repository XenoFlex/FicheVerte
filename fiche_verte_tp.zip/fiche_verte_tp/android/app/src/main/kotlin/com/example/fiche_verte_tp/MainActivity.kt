package com.example.fiche_verte_tp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
