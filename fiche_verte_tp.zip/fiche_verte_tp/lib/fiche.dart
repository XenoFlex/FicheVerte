import 'package:fiche_verte_tp/mainhome.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'page2.dart';

class FichePage extends StatefulWidget {
  @override
  _FichePageState createState() => _FichePageState();
}

class _FichePageState extends State<FichePage> {
  final _formKey = GlobalKey<FormState>();
  final _controllerName = TextEditingController();
  final _controllerPrenom = TextEditingController();
  final _controllerDateN = TextEditingController();
  final _controllerLieuN = TextEditingController();
  final _controllerRue = TextEditingController();
  final _controllerBatiment = TextEditingController();
  final _controllerVille = TextEditingController();
  final _controllerCode = TextEditingController();
  final _controllerTelfixe = TextEditingController();
  final _controllerTelport = TextEditingController();
  final _controllerTelpro = TextEditingController();
  final _controllerAdmail = TextEditingController();
  final _controllerAdemp = TextEditingController();


  void clicLogin() {
    if (_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Rapport de ' + _controllerName.text + ' Envoyé !')),
      );
      /*Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const MySecondScreen()),
      );*/
      //Navigator.pushNamed(context, '/second', arguments: (_controllerName.text));
      /*Navigator.pushNamed(context, ExtractArgumentScreen.routeName,
          arguments: ScreenArguments(_teLogin.text));*/

      var url = Uri.parse(
          'https://devweb.iutmetz.univ-lorraine.fr/~milon12u/flutter/demande.php?nom=' +
              _controllerName.text +
              '&prenom=' +
              _controllerPrenom.text +
              '&date_naissance=' +
              _controllerDateN.text +
              '&lieu_naissance=' +
              _controllerLieuN.text +
              '&rue=' +
              _controllerRue.text +
              '&batiment=' +
              _controllerBatiment.text +
              '&ville=' +
              _controllerVille.text +
              '&code_postal=' +
              _controllerCode.text +
              '&tel_fixe=' +
              _controllerTelfixe.text +
              '&tel_port=' +
              _controllerTelport.text +
              '&tel_pro=' +
              _controllerTelpro.text +
              '&ad_mail=' +
              _controllerAdmail.text +
              '&ad_empl=' +
              _controllerAdemp.text );
      http.get(url);
      print(url);
    }
  }

  @override
  void dispose() {
    _controllerName.dispose();
    _controllerPrenom.dispose();
    _controllerDateN.dispose();
    _controllerLieuN.dispose();
    _controllerRue.dispose();
    _controllerBatiment.dispose();
    _controllerVille.dispose();
    _controllerCode.dispose();
    _controllerTelfixe.dispose();
    _controllerTelport.dispose();
    _controllerTelpro.dispose();
    _controllerAdmail.dispose();
    _controllerAdemp.dispose();
    
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.document_scanner),
            SizedBox(width: 10),
            Text("Fiche Verte"),
          ],
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Form(
                key: _formKey,
                child: Column(
                  children: <Widget>[
                    SizedBox(
                        child: Center(
                            child: Text(
                          "Informations générales",
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.green,
                          ),
                        )),
                        height: 80),
                    Padding(
                      padding: EdgeInsets.all(12),
                      child: TextFormField(
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return '*Champ requis';
                          }
                          return null;
                        },
                      controller: _controllerName,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(), hintText: 'Nom'),
                    ),
                      ),

                    
                    Padding(
                      padding: EdgeInsets.all(12),
                      child: 
                    TextFormField(
                      validator: (value) {
                          if (value == null || value.isEmpty) {
                            return '*Champ requis';
                          }
                          return null;
                        },
                      controller: _controllerPrenom,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(), hintText: 'prenom'),
                    ),),

                    Padding(
                      padding: EdgeInsets.all(12),
                      child:
                    TextFormField(
                      controller: _controllerDateN,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(), hintText: 'date naissance'),
                    ),),

                    Padding(
                      padding: EdgeInsets.all(12),
                      child:
                    TextFormField(
                      controller: _controllerLieuN,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(), hintText: 'lieu naissance'),
                    ),),
                    
                    SizedBox(
                        child: Center(
                            child: Text(
                          "Adresse",
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.green,
                          ),
                        )),
                        height: 80),

                    Padding(
                      padding: EdgeInsets.all(12),
                      child:
                    TextFormField(
                      controller: _controllerRue,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(), hintText: 'Rue'),
                    ),),

                    Padding(
                      padding: EdgeInsets.all(12),
                      child:
                    TextFormField(
                      controller: _controllerBatiment,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(), hintText: 'Batiment'),
                    ),),

                    Padding(
                      padding: EdgeInsets.all(12),
                      child:
                    TextFormField(
                      validator: (value) {
                          if (value == null || value.isEmpty) {
                            return '*Champ requis';
                          }
                          return null;
                        },
                      controller: _controllerVille,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(), hintText: 'Ville'),
                    ),),

                    Padding(
                      padding: EdgeInsets.all(12),
                      child:
                    TextFormField(
                      controller: _controllerCode,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: 'Code Postal'),
                    ),),


                    SizedBox(
                        child: Center(
                            child: Text(
                          "Renseignements complémentaires",
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.green,
                          ),
                        )),
                        height: 80),

                    Padding(
                      padding: EdgeInsets.all(12),
                      child:
                    TextFormField(
                      validator: (value) {
                          if (value == null || value.isEmpty) {
                            return '*Au moins 1 des 3 Tel doit être rempli';
                          }
                          return null;
                        },
                      controller: _controllerTelfixe,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(), hintText: 'Telfixe'),
                    ),),

                    Padding(
                      padding: EdgeInsets.all(12),
                      child:
                    TextFormField(
                      controller: _controllerTelport,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(), hintText: 'Telport'),
                    ),),

                    Padding(
                      padding: EdgeInsets.all(12),
                      child:
                    TextFormField(
                      controller: _controllerTelpro,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(), hintText: 'Telpro'),
                    ),),

                    SizedBox(height: 40),

                    Padding(
                      padding: EdgeInsets.all(12),
                      child:
                    TextFormField(
                      controller: _controllerAdmail,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: 'Admail'),
                    ),),

                    Padding(
                      padding: EdgeInsets.all(12),
                      child:
                    TextFormField(
                      controller: _controllerAdemp,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: 'Adempl'),
                    ),),
                    SizedBox(height: 40),

                    /*
                  TextFormField(
                    controller: _teLogin,
                    decoration: const InputDecoration(
                        border: OutlineInputBorder(), hintText: 'Login'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Le login est obligatoire !';
                      } else if (value.contains('@')) {
                        return 'veuillez renseigner un login sans @';
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    //controller: _teLogin,
                    obscureText: true,
                    decoration: const InputDecoration(
                        border: OutlineInputBorder(), hintText: 'Password'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Le password est obligatoire !';
                      } else if (value.length < 6) {
                        return 'Le password est trop court !';
                      }
                      return null;
                    },
                  ),*/
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 16.0),
                      child: ElevatedButton(
                        onPressed: clicLogin,
                        child: const Text('Envoyer'),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
