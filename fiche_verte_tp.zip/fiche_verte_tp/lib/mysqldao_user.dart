import 'package:http/http.dart' as http;
import 'package:fiche_verte_tp/user.dart';

class MySQLDAOUser {
  static const String urlServeur =
      "https://devweb.iutmetz.univ-lorraine.fr/~milon12u/flutter/";

  static Future<List<User>> getUsers() async {
    final response =
        await http.get(Uri.parse(urlServeur + 'getid.php'));
    if (response.statusCode == 200) {
      return User.listeFromJsonString(response.body);
    } else {
      throw Exception('Impossible de charger les categories');
    }
  }
}
