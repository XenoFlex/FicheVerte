import 'package:fiche_verte_tp/mainhome.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'page2.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Fiche Verte',
        theme: ThemeData(
          primarySwatch: Colors.green,
        ),
        /*initialRoute: '/',
        routes: {
          // When navigating to the "/" route, build the FirstScreen widget.
          '/': (context) => const MyHomePage(),
          // When navigating to the "/second" route, build the SecondScreen widget.
          '/second': (context) => const MySecondScreen(),

        },*/
        home: MainHomePage(),
        );
  }
}

