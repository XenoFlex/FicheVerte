import 'dart:convert';
import 'dart:io';

import 'package:fiche_verte_tp/detail.dart';
import 'package:fiche_verte_tp/mainhome.dart';
import 'package:fiche_verte_tp/mysqldao_user.dart';
import 'package:fiche_verte_tp/user.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'page2.dart';

class RecherchePage extends StatefulWidget {
  @override
  _RecherchePageState createState() => _RecherchePageState();
}

class _RecherchePageState extends State<RecherchePage> {
  List<User>? _users;

  @override
  void initState() {
    _chargeUsers();
    super.initState();
  }

  void _chargeUsers() async {
    _users = await MySQLDAOUser.getUsers();
    setState(() {});
  }

  final TextEditingController _filter = new TextEditingController();
  String _searchText = "";
  List filteredNames = [];
  List names = [];
  Icon _searchIcon = new Icon(Icons.search);
  Widget _appBarTitle = new Text( 'Liste des Utilisateurs' );

  _ExamplePageState() {
    _filter.addListener(() {
      if (_filter.text.isEmpty) {
        setState(() {
          _searchText = "";
          filteredNames = names;
        });
      } else {
        setState(() {
          _searchText = _filter.text;
        });
      }
    });
  }

  void _searchPressed() {
  setState(() {
    if (this._searchIcon.icon == Icons.search) {
      this._searchIcon = new Icon(Icons.close);
      this._appBarTitle = new TextField(
        controller: _filter,
        decoration: new InputDecoration(
            prefixIcon: new Icon(Icons.search), hintText: 'Cherchez un utilisateur ...'),
      );
    } else {
      this._searchIcon = new Icon(Icons.search);
      this._appBarTitle = new Text('Liste des Utilisateurs');
      filteredNames = names;
      _filter.clear();
    }
  });
}
  TextEditingController _textController = TextEditingController();
  List<String> initialList = ["Chat", "Chien", "Rat", "Cheval", "Ours"];
  List<String> filteredList = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: _appBarTitle,
        leading: new IconButton(
          icon: _searchIcon,
          onPressed: _searchPressed,
        ),
      ),
      body: _users == null
          ? const Center(
              child: Text("Chargement en cours..."),
            )
          : SingleChildScrollView(
              child: Column(
              children: <Widget>[
                for (var idx = 0; idx < _users!.length; idx++)
                  GestureDetector(
                          onTap: () {Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PageDetail(),
                        ),
                      );
                      //print("Container 2 clicked");
                    },
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 22, vertical: 10),
                    width: MediaQuery.of(context).size.width,
                    height: 200,
                    decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.6),
                          offset: Offset(
                            0.0,
                            10.0,
                          ),
                          blurRadius: 10.0,
                          spreadRadius: -6.0,
                        ),
                      ],
                      image: DecorationImage(
                        colorFilter: ColorFilter.mode(
                          Colors.black.withOpacity(0.65),
                          BlendMode.multiply,
                        ),
                        image: NetworkImage(
                            "https://cdn.radiofrance.fr/s3/cruiser-production/2020/06/49762dcd-d2e5-4f56-933b-4f86f8e30b2f/870x489_index.jpg"),
                        fit: BoxFit.cover,
                      ),
                    ),
                    child: Stack(
                      children: [
                        Align(
                          child: Padding(
                            padding: EdgeInsets.symmetric(horizontal: 5.0),
                            child: Text(
                              _users![idx].nom + " " + _users![idx].prenom,
                              style: TextStyle(
                                fontSize: 28, //taille police titre
                                color: Colors.green,
                                fontWeight: FontWeight.bold,
                              ),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 2,
                              textAlign: TextAlign.center,
                            ),
                          ),
                          alignment: Alignment.center,
                        ),
                        Align(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                padding: EdgeInsets.all(5),
                                margin: EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.4),
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.location_on,
                                      color: Colors.green,
                                      size: 18,
                                    ),
                                    SizedBox(width: 7),
                                    Text(
                                      _users![idx].ville,
                                      style: TextStyle(
                                        color: Colors.green,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.all(5),
                                margin: EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.4),
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                child: Row(
                                  children: [
                                    /*Icon(
                          Icons.schedule,
                          color: Colors.yellow,
                          size: 18,
                        ),
                        SizedBox(width: 7),
                        Text(cookTime),*/
                                  ],
                                ),
                              )
                            ],
                          ),
                          alignment: Alignment.bottomLeft,
                        ),
                      ],
                    ),
                  ),
                ),/*
                TextField(
              controller: _textController,
              onChanged: (text) {
                text = text.toLowerCase();
                setState(() {
                  filteredList = initialList
                      .where((element) => element.toLowerCase().contains(text))
                      .toList();
                });
              },
            ),
            if (filteredList.length == 0 && _textController.text.isEmpty)
              Expanded(
                  child: ListView.builder(
                      itemCount: initialList.length,
                      itemBuilder: (BuildContext context, index) {
                        return Container(
                          height: 50,
                          child: Text(initialList[index]),
                        );
                      }))
            else if (filteredList.length==0 && _textController.text.isNotEmpty)
              Expanded(
                child: Container(
                  child: Text('Aucune donnée'),
                ),
              )
            else
              Expanded(
                child: ListView.builder(
                    itemCount: filteredList.length,
                    itemBuilder: (BuildContext context, index) {
                      return Container(
                        height: 50,
                        child: Text(filteredList[index]),
                      );
                    }),
              ),*/
              ],
            )

              /*
          : ListView(
              padding: const EdgeInsets.all(10),
              children: <Widget>[
                for (var idx = 0; idx < _users!.length; idx++)
                  ListTile(
                    title: Text(_users![idx].nom),
                    trailing: Icon(Icons.remove_circle,
                        color: Theme.of(context).primaryColor),
                    onTap: () {
                      _showDialogSuppr(_users![idx]);
                    },
                  ),
              ],
            ),*/
              ),
    );
  }

  void _showDialogSuppr(User categorieSelectionnee) {
    showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('Etes-vous sûr que vous voulez supprimer ?'),
        content: Text(categorieSelectionnee.nom),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(context, 'Cancel'),
            child: const Text('ANNULER'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                _users!.remove(categorieSelectionnee);
              });
              Navigator.pop(context, 'OK');
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }
}


