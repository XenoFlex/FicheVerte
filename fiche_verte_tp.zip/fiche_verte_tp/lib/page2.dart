import 'package:flutter/material.dart';
import 'main.dart';

class MySecondScreen extends StatefulWidget {
  const MySecondScreen({Key? key,}) : super(key: key);
  //final int valeur;
  @override
  State<MySecondScreen> createState() => _MySecondScreenState();
}

class _MySecondScreenState extends State<MySecondScreen> {
  final _formKey = GlobalKey<FormState>();
  final _teLogin = TextEditingController();
  final _tePass = TextEditingController();

  void clicUpdate() {
    if (_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Mot de passe modifié !')),
      );
      /*Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const MySecondScreen()),
      );*/
      Navigator.pop(context);
    }
  }

  void clicBack() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Bon retour au menu !')),
    );
    Navigator.pop(context);
  }

  /*@override
  void initState() {
    _valeur = widget.valeur;
    super.initState();
  }*/

  bool bonMotdepasse(password) {
    bool hasUppercase = false;
    bool hasDigits = false;
    bool hasLowercase = false;
    bool res = false;
    if (password.contains(RegExp(r'[A-Z]'))) {
      hasUppercase = true;
      //print('majuscule');
    } 
    if (password.contains(RegExp(r'[0-9]'))) {
      hasDigits = true;
      //print('chiffre');
    } 
    if (password.contains(RegExp(r'[a-z]'))) {
      hasLowercase = true;
      //print('majuscule');
    }

    if (hasUppercase && hasDigits && hasLowercase) {
      res = true;
      return res;
    } else {
      res = false;
      return res;
    }
  }

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)!.settings.arguments as String;
    return Scaffold(
      appBar: AppBar(
        title: Text('Rapport de ' + args),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text(
              'Page 2 : Modification de mot de passe',
            ),
            Form(
              key: _formKey,
              child: Column(
                children: <Widget>[
                  TextFormField(
                    controller: _teLogin,
                    decoration: const InputDecoration(
                        border: OutlineInputBorder(), hintText: 'New Password'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Le password est obligatoire !';
                      } else if (value.length < 7) {
                        return 'Le password est trop court !';
                      } else if (!bonMotdepasse(value)) {
                        return 'mot de passe incorect, il doit contenir au moins : une majuscule, une minuscule, un chiffre';
                      }
                    },
                  ),
                  TextFormField(
                    controller: _tePass,
                    decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: 'Please enter again the new Password'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Le password est obligatoire !';
                      } else if (_teLogin.text != _tePass.text) {
                        return 'les mots de passes doivent être identiques';
                      }
                      /*if (value.compareTo(_teLogin) == 0)
                      return null;*/
                    },
                  ),
                  Padding(
                      padding: const EdgeInsets.symmetric(vertical: 16.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: <Widget>[
                          ElevatedButton(
                            onPressed: clicBack,
                            child: const Text('Annuler'),
                          ),
                          ElevatedButton(
                            onPressed: clicUpdate,
                            child: const Text('Valider'),
                          ),
                        ],
                      )),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}