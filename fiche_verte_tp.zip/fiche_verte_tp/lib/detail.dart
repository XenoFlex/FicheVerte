import 'dart:convert';
import 'dart:io';

import 'package:fiche_verte_tp/mainhome.dart';
import 'package:fiche_verte_tp/mysqldao_user.dart';
import 'package:fiche_verte_tp/user.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'page2.dart';

class PageDetail extends StatefulWidget {
  @override
  _PageDetailState createState() => _PageDetailState();
}

class _PageDetailState extends State<PageDetail> {
  List<User>? _users;

  @override
  void initState() {
    _chargeUsers();
    super.initState();
  }

  void _chargeUsers() async {
    _users = await MySQLDAOUser.getUsers();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Détail de l'utilisateur"),
      ),

      body: Center(
        child: Text("--> Détails à inclure <--"),
      ),
    );
    
    }

}
