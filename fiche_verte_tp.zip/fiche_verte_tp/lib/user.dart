import 'dart:convert';

class User {
  // Les attributs ne sont pas 'final' car dans un cas plus complet
  // est amené à modifier les valeurs
  int _id;
  String _nom;
  String _prenom;
  String _ville;

  get nom {
    return _nom;
  }

  get prenom {
    return _prenom;
  }

  get ville {
    return _ville;
  }


  User(this._id, this._nom, this._prenom, this._ville);

  @override
  String toString() {
    return _nom;
  }

  // Méthode utiisée par la DAO pour créer une
  // liste d'instances de Categorie
  // à partir d'une liste d'objets JSON
  static List<User> listeFromJsonString(String sJSON) {
    List<User> liste = [];

    var json = jsonDecode(sJSON);

    for (var value in json) {
      liste.add(User(int.parse(value['id']),value['nom'],value['prenom'],value['ville'],));
    }

    return liste;
  }
}
